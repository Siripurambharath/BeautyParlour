import React, { useState } from 'react';
import {
  Box, TextField, FormControl, MenuItem, InputLabel, Select,
  Button, Paper, Typography, AppBar, Toolbar, IconButton,
} from '@mui/material';
import { useNavigate, Link } from 'react-router-dom';
import ladylogo from './images/lady logo.png';

const Beautyedit = () => {
  const navigate = useNavigate();
  const [anchorEl, setAnchorEl] = useState(null);
  const [view, setView] = useState('beautyedit');  // Define the 'view' state here
  const open = Boolean(anchorEl);

  const handleClick = (event) => setAnchorEl(event.currentTarget);
  const handleClose = () => setAnchorEl(null);

  const handleSubmit = (event) => {
    event.preventDefault();
    navigate('/beautytable');
  };

  const handleLogoClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  return (
    <>
      {/* AppBar */}
      <AppBar position="static" color="primary" sx={{ width: '100vw', left: 0 }}>
        <Toolbar sx={{ px: 2, display: 'flex', justifyContent: 'space-between' }}>
          {/* Left: Logo + Title */}
          <Box sx={{ display: 'flex', alignItems: 'center', flex: 1 }}>
            <IconButton edge="start" color="inherit" onClick={handleLogoClick} sx={{ mr: 1 }}>
              <img src={ladylogo} alt="Logo" style={{ height: 40, borderRadius: '50%' }} />
            </IconButton>
            <Typography variant="subtitle1" component="div" sx={{ fontSize: '1.1rem' }}>
              BeautyParlour
            </Typography>
          </Box>

          {/* Center: Category & Registration */}
         <Box sx={{ display: 'flex', justifyContent: 'space-between', flex: 1 }}>
                  <Button color="inherit" sx={{ fontSize: '1.1rem' }} component={Link} to="/beautycategory">
                    Category
                  </Button>
                  <Button color="inherit" sx={{ fontSize: '1.1rem' }} component={Link} to="/beautycategory">
                    Registration
                  </Button>
                </Box>

          {/* Right: Logout */}
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', flex: 1 }}>
            <Button color="inherit" component={Link} to="/beautylogin" sx={{ fontSize: '1.1rem' }}>
              Logout
            </Button>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Form */}
      <Box component="form" sx={{ mt: 2 }} onSubmit={handleSubmit}>
        <Paper elevation={3} sx={{ p: 3, mb: 1, maxWidth: 700, height: 440, mx: 'auto' }}>
          <Box sx={{ backgroundColor: '#29b6f6', padding: 2 ,mb:2}}>
            <Typography variant='h5' sx={{ textAlign: 'center', color: '#7b1fa2' }}>
              Update Form
            </Typography>
          </Box>

              <Box sx={{ display: 'flex', gap: 3 }}>
     <TextField fullWidth label="Full Name" margin="normal" />
     <TextField fullWidth label="Phone Number" margin="normal" type="number" />
   </Box>
   
   <Box sx={{ display: 'flex', gap: 3 }}>
     <TextField fullWidth label="Email" margin="normal" type="email" />
     <TextField fullWidth label="Address" margin="normal" />
   </Box>

            <Box sx={{ display: 'flex', gap: 3, mt: 2 }}>
       <FormControl fullWidth>
         <InputLabel id="service-label">Service</InputLabel>
         <Select labelId="service-label" defaultValue="">
           <MenuItem value="haircut">Haircut</MenuItem>
           <MenuItem value="facial">Facial</MenuItem>
           <MenuItem value="makeup">Makeup</MenuItem>
           <MenuItem value="face-makeup">Face Makeup</MenuItem>
           <MenuItem value="skin">Skin</MenuItem>
         </Select>
       </FormControl>
     
       <FormControl fullWidth>
         <InputLabel id="location-label">Location</InputLabel>
         <Select labelId="location-label" defaultValue="">
           <MenuItem value="Sircilla">Sircilla</MenuItem>
           <MenuItem value="Chandrampet">Chandrampet</MenuItem>
           <MenuItem value="Mandepelly">Mandepelly</MenuItem>
           <MenuItem value="Agraharam">Agraharam</MenuItem>
           <MenuItem value="Ragudu">Ragudu</MenuItem>
           <MenuItem value="ChinnaBonala">Chinna Bonala</MenuItem>
         </Select>
       </FormControl>
     </Box>

        <Box sx={{ display: 'flex', gap: 3 }}>
                    <TextField fullWidth type="date" margin="normal" />
                    <TextField fullWidth label="Estimated Cost" type="number" margin="normal" />
                    </Box>

         <Box sx={{ mt: 2 ,textAlign:'center'}}>
                     <Button type="submit" variant="contained" color="primary">
                       Update Form
                     </Button>
                   </Box>
        </Paper>
      </Box>
    </>
  );
};

export default Beautyedit;
