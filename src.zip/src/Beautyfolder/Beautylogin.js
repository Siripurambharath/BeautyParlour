import { Box, Container, Grid, TextField, Typography, Button, IconButton, InputAdornment } from '@mui/material';
import { Link } from 'react-router-dom';
import React, { useState } from 'react';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';

const LoginCar = () => {
    const [showPassword, setShowPassword] = useState(false);

    const handleTogglePassword = () => {
        setShowPassword((prev) => !prev);
    };

    return (

            <Box
            sx={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                minHeight: '100vh',
                backgroundColor: '#9e9e9e',
            }}
        >
        <Box
            sx={{
                display: 'flex',
                justifyContent: 'center',
                alignItems: 'center',
                minHeight: '100vh',
            }}
        >
            <Box
                sx={{
                    maxWidth: 500,
                    mx: 'auto',
                    p: 3,
                    border: '3px solid #ccc',
                    borderRadius: 2,
                    boxShadow: 3,
                    backgroundColor: '#fff',
                }}
            >
                <Container maxWidth="sm" sx={{ mt: 2 }}>
                    <Typography variant='h5' sx={{ color: '#9c27b0' }} gutterBottom align='center'>
                        Login Form
                    </Typography>

                    <form>
                        <Grid container spacing={2}>
                            <TextField
                                label='First Name'
                                fullWidth
                                required
                                margin='normal'
                    
                                  
                            />

                            <TextField
                                label="Phone Number"
                                fullWidth
                                required
                                margin='normal'
                                type='number'
                            />

                            {/* Password Field with Eye Icon */}
                            <TextField
                                label="Password"
                                fullWidth
                                required
                                margin='normal'
                                type={showPassword ? 'text' : 'password'}
                                InputProps={{
                                    endAdornment: (
                                        <InputAdornment position="end">
                                            <IconButton
                                                onClick={handleTogglePassword}
                                                edge="end"
                                            >
                                                {showPassword ? <VisibilityOff fontSize="small"/> : <Visibility fontSize="small" />}
                                            </IconButton>
                                        </InputAdornment>
                                    )
                                }}
                            />
                        </Grid>

                        {/* Submit Button */}
                        <Button
                            type="submit"
                            variant='contained'
                            component={Link}
                            to="/beautytable"
                            fullWidth
                            sx={{ mt: 3 }}
                        >
                            Submit
                        </Button>

                        {/* Sign Up (empty box for future) */}
                        <Box
                            sx={{
                                display: 'flex',
                                flexDirection: 'column',
                                justifyContent: 'center',
                                alignItems: 'center',
                                mt: 2,
                                textAlign: 'center',
                            }}
                        >
                            {/* you can add "Don't have account? Sign Up" here */}
                        </Box>

                    </form>
                </Container>
            </Box>
        </Box>
        </Box>
    );
};

export default LoginCar;
