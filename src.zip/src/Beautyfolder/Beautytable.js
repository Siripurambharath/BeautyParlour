import React, { useState } from 'react';
import {
  Typography,
  Box,
  Button,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableBody,
  TableCell,
  Paper,
  Stack,
  TextField,
  IconButton,
  AppBar,
  Toolbar,
} from '@mui/material';
import { Link } from 'react-router-dom';
import AddIcon from '@mui/icons-material/Add';
import VisibilityIcon from '@mui/icons-material/Visibility';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import ladylogo from './images/lady logo.png';
import TablePagination from '@mui/material/TablePagination';

const users = [
  {
    id: 1,
    name: 'Anuskha',
    Service: 'Facial',
    PhoneNumber: '6302403398',
    email: 'anuskha@gmail.com',
    address: '123 Main Street',
    Location: 'Sircilla',
    Amount: '500',
    Date: '23-04-2025',
  },
  {
    id: 2,
    name: 'Kajal',
    Service: 'Haircut',
    PhoneNumber: '6301402298',
    email: 'kajal98@gmail.com',
    address: '129 Main Street',
    Location: 'Mandepelly',
    Amount: '450',
    Date: '22-04-2025',
  },
  {
    id: 3,
    name: 'Malavika',
    Service: 'Skin',
    PhoneNumber:'9290812425',
    email: 'malavika@gmail.com',
    address: '120 down Street',
    Location:'Ragudu',
    Amount:'250',
    Date:'22-04-2025',
  },
  {
    id: 4,
    name: 'Latha',
    Service: 'Makeup',
    PhoneNumber:'8464087790',
    email: 'latha@gmail.com',
    address: '139 Main Street',
    Location:'Agraharam',
    Amount:'1000',
    Date:'22-04-2025',
  },
  {
    id: 5,
    name: 'Halini',
    Service: 'FaceMakeup',
    PhoneNumber:'9833989009',
    email: 'halini@gmail.com',
    address: 'rajivnagar MainStreet',
    Location:'Chandrampet',
    Amount:'850',
    Date:'21-04-2025',
  },
  {
    id: 6,
    name: 'Mounika',
    Service: 'Haircut',
    PhoneNumber:'7337050794',
    email: 'mounika@gmail.com',
    address: '300 Main Street',
    Location:'Chinna Bonala',
    Amount:'200',
    Date:'22-04-2025',
  },
  {
    id: 7,
    name: 'Hema',
    Service: 'Skin',
    PhoneNumber:'8893389390',
    email: 'hema@gmail.com',
    address: '009 Main Street',
    Location:'Sircilla',
    Amount:'250',
    Date:'22-04-2025',
  },
  {
    id: 8,
    name: 'Meena',
    Service: 'Haircut',
    PhoneNumber:'9301482298',
    email: 'meeena@gmail.com',
    address: '229 middle Street',
    Location:'agrharam',
    Amount:'450',
    Date:'22-04-2025',
  },
  {
    id: 9,
    name: 'kavya',
    Service: 'skin',
    PhoneNumber:'9801470028',
    email: 'kavya@gmail.com',
    address: '298 down Street',
    Location:'Sircilla',
    Amount:'450',
    Date:'21-04-2025',
  },
  {
    id: 10,
    name: 'premalatha',
    Service: 'Haircut',
    PhoneNumber:'9160188248',
    email: 'premalatha@gmail.com',
    address: '200 down Street',
    Location:'Sircilla',
    Amount:'450',
    Date:'22-04-2025',
  },
  {
    id: 11,
    name: 'Vani',
    Service: 'Makepu',
    PhoneNumber:'8924188248',
    email: 'vani@gmail.com',
    address: '20 down Street',
    Location:'chandrampet',
    Amount:'550',
    Date:'21-04-2025',
  },



];

const handleDelete = (id) => {
  console.log('Delete user with ID:', id);
};

const BeautyTable = () => {
  const [search, setSearch] = useState('');
  const [anchorEl, setAnchorEl] = useState(null);
    const [view, setView] = useState(null);
  const open = Boolean(anchorEl);

  const handleSearchChange = (event) => {
    setSearch(event.target.value);
  };

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleLogoClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };


  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(5);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(parseInt(event.target.value, 5));
    setPage(0);
  };
 

  
  
  return (
    <Box>
      <AppBar position="static" color="primary" sx={{ width: '100vw', left: 0 }}>
        <Toolbar sx={{ px: 2, display: 'flex', justifyContent: 'space-between' }}>
          <Box sx={{ display: 'flex', alignItems: 'center', flex: 1 }}>
            
          <IconButton edge="start" color="inherit" onClick={handleLogoClick} sx={{ mr: 1 }}>
              <img src={ladylogo} alt="Logo" style={{ height: 40, borderRadius: '50%' }} />
            </IconButton>
            <Typography variant="subtitle1" component="div" sx={{ fontSize: '1.1rem' }}>
              BeautyParlour
            </Typography>
          </Box>

          <Box sx={{ display: 'flex', justifyContent: 'space-between', flex: 1 }}>
            <Button color="inherit" sx={{ fontSize: '1.1rem' }} component={Link} to="/beautycategory">
              Category
            </Button>
            <Button color="inherit" sx={{ fontSize: '1.1rem' }} component={Link} to="/beautycategory">
              Registration
            </Button>
          </Box>

          <Box sx={{ display: 'flex', justifyContent: 'flex-end', flex: 1 }}>
            <Button color="inherit" component={Link} to="/beautylogin" sx={{ fontSize: '1.1rem' }}>
              Logout
            </Button>
          </Box>
        </Toolbar>
      </AppBar>

      <Box sx={{ maxWidth: 1250, mx: 'auto', p: 2, borderRadius: 2, boxShadow: 3, backgroundColor: '#fff' }}>
        <Typography variant="h4" sx={{ textAlign: 'center', color: 'error.main' }}>
          Beauty-Parlour Table
        </Typography>

        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mt: 1, mb: 1 }}>
          <Box sx={{ mb: 1, width: '200px' }}>
            <TextField
              id="search"
              label="Search Name"
              variant="outlined"
              value={search}
              onChange={handleSearchChange}
              placeholder="Search..."
              fullWidth
              size="small"
              sx={{
                backgroundColor: 'white',
                borderRadius: 1,
                '& .MuiOutlinedInput-root': {
                  borderRadius: '8px',
                },
              }}
            />
          </Box>

          <Button
            sx={{ marginRight: 3 }}
            aria-label="add"
            variant="contained"
            component={Link}
            to="/beautycategory"
          >
            <AddIcon />
          </Button>
        </Box>

        <TableContainer component={Paper}>
          <Table>
            <TableHead sx={{ backgroundColor: '#1976d2' }}>
              <TableRow>
                {['ID', 'Name', 'Service', 'Phone Number', 'Email', 'Address', 'Location', 'Amount', 'Date', 'Actions'].map((head) => (
                  <TableCell key={head} sx={{ color: 'white', textAlign: 'center', fontSize: '16px' }}>
                    <strong>{head}</strong>
                  </TableCell>
                ))}
              </TableRow>
            </TableHead>

            <TableBody>
              {users
                .filter((user) => user.name.toLowerCase().includes(search.toLowerCase())) // Filtering based on search
                .map((user, index) => (
                  <TableRow
                    key={user.id}
                    sx={{
                      backgroundColor: [0, 2, 4, 6, 8].includes(index) ? '#eeeeee' : 'inherit',
                    }}
                  >
                    <TableCell sx={{ textAlign: 'center' }}>{user.id}</TableCell>
                    <TableCell sx={{ textAlign: 'center' }}>{user.name}</TableCell>
                    <TableCell sx={{ textAlign: 'center' }}>{user.Service}</TableCell>
                    <TableCell sx={{ textAlign: 'center' }}>{user.PhoneNumber}</TableCell>
                    <TableCell sx={{ textAlign: 'center' }}>{user.email}</TableCell>
                    <TableCell sx={{ textAlign: 'center' }}>{user.address}</TableCell>
                    <TableCell sx={{ textAlign: 'center' }}>{user.Location}</TableCell>
                    <TableCell sx={{ textAlign: 'center' }}>{user.Amount}</TableCell>
                    <TableCell sx={{ textAlign: 'center' }}>{user.Date}</TableCell>
                    <TableCell sx={{ textAlign: 'center' }}>
                      <Box display="flex" justifyContent="center" gap={1}>
                        <Stack direction="row" spacing={1}>
                          <IconButton color="info" component={Link} to="/beautyview" size="small">
                            <VisibilityIcon />
                          </IconButton>
                          <IconButton color="secondary" component={Link} to="/beautyedit" size="small">
                            <EditIcon />
                          </IconButton>
                        </Stack>
                        <IconButton color="error" size="small" onClick={() => handleDelete(user.id)}>
                          <DeleteIcon />
                        </IconButton>
                      </Box>
                    </TableCell>
                  </TableRow>
                ))}
            </TableBody>
          </Table>
          <TablePagination
      component="div"
      count={users.filter((user) => user.name.toLowerCase().includes(search.toLowerCase())).length}
      page={page}
      onPageChange={handleChangePage}
      rowsPerPage={rowsPerPage}
      onRowsPerPageChange={handleChangeRowsPerPage}
    />
        </TableContainer>
      </Box>
  
    </Box>
  );
};

export default BeautyTable;
