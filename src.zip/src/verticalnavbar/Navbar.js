import React from 'react';
import { Box, List, ListItem, ListItemButton, ListItemIcon, ListItemText } from '@mui/material';
import HomeIcon from '@mui/icons-material/Home';
import GroupIcon from '@mui/icons-material/Group';
import ContactsIcon from '@mui/icons-material/Contacts';
import WorkIcon from '@mui/icons-material/Work';
import SignalCellularAltIcon from '@mui/icons-material/SignalCellularAlt';
import PeopleIcon from '@mui/icons-material/People';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import LabelIcon from '@mui/icons-material/Label';
import ArchiveIcon from '@mui/icons-material/Archive';
import ReportIcon from '@mui/icons-material/Report';
import LocalShippingIcon from '@mui/icons-material/LocalShipping';

const Navbar = () => {
  return (
    <Box
      sx={{
        width: 220,
        backgroundColor: '#4dd0e1',
        height: '102vh',
        paddingTop: 1,
        display:'flex',
        justifyContent:'center',
        alignItems:'center'
      }}
    >
      <List>
        <ListItem disablePadding>
          <ListItemButton>
            <ListItemIcon sx={{ color: '#212121', fontSize: 15 }}>
              <HomeIcon />
            </ListItemIcon>
            <ListItemText primary="Home" sx={{ fontSize: 12}} />
          </ListItemButton>
        </ListItem>

        <ListItem disablePadding>
          <ListItemButton>
            <ListItemIcon sx={{ color: '#212121', fontSize: 15 }}>
              <GroupIcon />
            </ListItemIcon>
            <ListItemText primary="All Leads" sx={{ fontSize: 12 }} />
          </ListItemButton>
        </ListItem>

        <ListItem disablePadding>
          <ListItemButton>
            <ListItemIcon sx={{ color: '#212121', fontSize: 15 }}>
              <ContactsIcon />
            </ListItemIcon>
            <ListItemText primary="My Leads" sx={{ fontSize: 12 }} />
          </ListItemButton>
        </ListItem>

        <ListItem disablePadding>
          <ListItemButton>
            <ListItemIcon sx={{ color: '#212121', fontSize: 15}}>
            <SignalCellularAltIcon  />
            </ListItemIcon>
            <ListItemText primary="All Opportunities" sx={{ fontSize: 12 }} />
          </ListItemButton>
        </ListItem>

        <ListItem disablePadding>
          <ListItemButton>
            <ListItemIcon sx={{ color: '#212121', fontSize: 15 }}>
            <WorkIcon  />
            </ListItemIcon>
            <ListItemText primary="My Opportunities" sx={{ fontSize: 12 }} />
          </ListItemButton>
        </ListItem>

        <ListItem disablePadding>
          <ListItemButton>
            <ListItemIcon sx={{ color: '#212121', fontSize: 15 }}>
              <PeopleIcon />
            </ListItemIcon>
            <ListItemText primary="All Customer" sx={{ fontSize: 12 }} />
          </ListItemButton>
        </ListItem>

        <ListItem disablePadding>
          <ListItemButton>
            <ListItemIcon sx={{ color: '#212121', fontSize: 15 }}>
              <LocationOnIcon />
            </ListItemIcon>
            <ListItemText primary="All Destinations" sx={{ fontSize: 12 }} />
          </ListItemButton>
        </ListItem>

        <ListItem disablePadding>
          <ListItemButton>
            <ListItemIcon sx={{ color: '#212121', fontSize: 15 }}>
              <LabelIcon />
            </ListItemIcon>
            <ListItemText primary="All Tags" sx={{ fontSize: 12 }} />
          </ListItemButton>
        </ListItem>

        <ListItem disablePadding>
          <ListItemButton>
            <ListItemIcon sx={{ color: '#212121', fontSize: 15}}>
              <ArchiveIcon />
            </ListItemIcon>
            <ListItemText primary="Archived Data" sx={{ fontSize: 12 }} />
          </ListItemButton>
        </ListItem>

        <ListItem disablePadding>
          <ListItemButton>
            <ListItemIcon sx={{ color: '#212121', fontSize: 15 }}>
              <PeopleIcon />
            </ListItemIcon>
            <ListItemText primary="All Teams" sx={{ fontSize: 12 }} />
          </ListItemButton>
        </ListItem>

        <ListItem disablePadding>
          <ListItemButton>
            <ListItemIcon sx={{ color: '#212121', fontSize: 15 }}>
              <ReportIcon />
            </ListItemIcon>
            <ListItemText primary="Report" sx={{ fontSize: 12 }} />
          </ListItemButton>
        </ListItem>

        <ListItem disablePadding>
          <ListItemButton>
            <ListItemIcon sx={{ color: '#212121', fontSize: 15 }}>
              <LocalShippingIcon />
            </ListItemIcon>
            <ListItemText primary="Suppliers" sx={{ fontSize: 12 }} />
          </ListItemButton>
        </ListItem>
      </List>
    </Box>
  );
};

export default Navbar;
