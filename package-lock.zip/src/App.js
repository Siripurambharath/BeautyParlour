import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Beautyreg from "./Beautyfolder/Beautyreg";
import Beautytable from "./Beautyfolder/Beautytable";
import Beautyview from "./Beautyfolder/Beautyview";
import Beautyedit from "./Beautyfolder/Beautyedit";
import Beautylogin from "./Beautyfolder/Beautylogin";
import Beautycategory from "./Beautyfolder/Beautycategory";















const App = () => {
  return (
    <Router>
      <Routes>
      <Route path="/beautyreg" element={<Beautyreg />} />
      <Route path="/beautytable" element={<Beautytable />} />
      <Route path="/beautyview" element={<Beautyview />} />
      <Route path="/beautyedit" element={<Beautyedit />} />
      <Route path="/beautylogin" element={<Beautylogin />} />
      <Route path="/beautycategory" element={<Beautycategory />} />
        












      </Routes>
    </Router>
  );
};

export default App;