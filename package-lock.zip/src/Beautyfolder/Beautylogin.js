import { Box, Container, Grid, TextField, Typography, Button, } from '@mui/material';
import { Link } from 'react-router-dom';
import React from 'react';

const LoginCar = () => {
    return (
        

        <Box
  sx={{
    display: 'flex',  
    justifyContent: 'center',
    alignItems: 'center',  
    minHeight: '100vh',
  }}
>
        <Box
        sx={{
          maxWidth: 500,
          mx: 'auto',  
          p: 3,
          border: '3px solid #ccc',
          borderRadius: 2,
          boxShadow: 3,
          backgroundColor: '#fff',
        }}
      >
        {/* Content goes here */}
    
            <Container maxWidth="sm" sx={{ mt: 2 }}>
                <Typography variant='h5' sx={{ color: '#9c27b0' }} gutterBottom align='center'>
                    Login Form
                </Typography>
                <form>
                    <Grid container spacing={2}>
                        <TextField
                            label='First Name'
                            fullWidth required
                            margin='normal'
                        />
                
                                <TextField
                            label="Phone Number"
                            fullWidth required
                            margin='normal'
                            type='number'
                        />
                        <TextField
                            label="Password"
                            fullWidth required
                            margin='normal'
                            type='password'
                        />
                    </Grid>

                    {/* Submit Button */}
                    <Button
                        type="submit"
                        variant='contained'
                        component={Link}
                        to="/beautytable"
                        fullWidth
                        sx={{ mt: 3 }}
                    >
                        Submit
                    </Button>

                    {/* Sign Up Button Below */}
                    <Box
                        sx={{
                            display: 'flex',
                            flexDirection: 'column',
                            justifyContent: 'center',
                            alignItems: 'center',
                            mt: 2,
                            textAlign: 'center',
                        }}
                    >

                    </Box>

                </form>
            </Container>
        </Box>
        </Box>
    );
};

export default LoginCar;
