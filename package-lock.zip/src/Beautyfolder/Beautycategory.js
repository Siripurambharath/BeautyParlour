import React, { useState, useEffect } from 'react';
import axios from 'axios'; // <-- Add this
import {
  AppBar,
  Box,
  Toolbar,
  Typography,
  IconButton,
  Button,
  Paper,
  Container,
  TextField,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  Table,
  TableContainer,
  TableRow,
  TableBody,
  TableCell,
  TableHead,
} from '@mui/material';
import { Link, useNavigate } from 'react-router-dom';
import ladylogo from './images/lady logo.png';
import CalendarTodayIcon from '@mui/icons-material/CalendarToday';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';

const Beautycategory = () => {
  const [view, setView] = useState(null);
  const [rows, setRows] = useState([]);
  const [newService, setNewService] = useState('');
  
  const [editId, setEditId] = useState(null);
const [editServiceName, setEditServiceName] = useState('');


  const navigate = useNavigate();

  // Load services from API
  const fetchServices = async () => {
    try {
      const res = await axios.get('http://localhost:5000/api/services');
      setRows(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchServices();
  }, []);

  const handleLogoClick = (event) => { };

  const handleDelete = async (id) => {
    try {
      await axios.delete(`http://localhost:5000/api/services/${id}`);
      fetchServices();
    } catch (err) {
      console.error(err);
    }
  };

  const handleAddService = async () => {
    if (!newService.trim()) return;

    try {
      await axios.post('http://localhost:5000/api/services', { service_name: newService });
      setNewService('');
      fetchServices();
    } catch (err) {
      console.error(err);
    }
  };

  const startEditing = (row) => {
    setEditId(row.id);
    setEditServiceName(row.service_name);
  };
  
  const handleUpdateService = async (id) => {
    try {
      await axios.put(`http://localhost:5000/api/services/${id}`, { service_name: editServiceName });
      setEditId(null);
      setEditServiceName('');
      fetchServices();
    } catch (err) {
      console.error(err);
    }
  };
  

  const handleSubmit = (event) => {
    event.preventDefault();
    navigate('/beautytable');
  };

  return (
    <>
      <AppBar position="static" color="primary" sx={{ width: '100vw', left: 0 }}>
        <Toolbar sx={{ px: 2, display: 'flex', justifyContent: 'space-between' }}>
          {/* Left: Logo + Title */}
          <Box sx={{ display: 'flex', alignItems: 'center', flex: 1 }}>
            <IconButton edge="start" color="inherit" onClick={handleLogoClick} sx={{ mr: 1 }}>
              <img src={ladylogo} alt="Logo" style={{ height: 40, borderRadius: '50%' }} />
            </IconButton>
            <Typography variant="subtitle1" component="div" sx={{ fontSize: '1.1rem' }}>
              BeautyParlour
            </Typography>
          </Box>

          {/* Center: Category & Registration */}
          <Box sx={{ display: 'flex', justifyContent: 'space-between', flex: 1 }}>
            <Button
              color="inherit"
              onClick={() => setView('category')}
              sx={{
                fontSize: '1.1rem',
                '&:hover': {
                  backgroundColor: '#42a5f5',
                  boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.1)',
                },
                backgroundColor: view === 'category' ? '#26a69a' : 'transparent',
                color: view === 'category' ? '#fff' : 'inherit',
              }}
            >
              Category
            </Button>
            <Button
              color="inherit"
              onClick={() => setView('registration')}
              sx={{
                fontSize: '1.1rem',
                '&:hover': {
                  backgroundColor: '#42a5f5',
                  boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.1)',
                },
                backgroundColor: view === 'registration' ? '#26a69a' : 'transparent',
                color: view === 'registration' ? '#fff' : 'inherit',
              }}
            >
              Registration
            </Button>

          </Box>

          {/* Right: Logout */}
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', flex: 1 }}>
            <Button color="inherit" component={Link} to="/beautylogin" sx={{
              fontSize: '1.1rem', '&:hover': {
                backgroundColor: '#42a5f5',
                boxShadow: '0px 4px 6px rgba(0, 0, 0, 0.1)',
              },
            }}>
              Logout
            </Button>
          </Box>
        </Toolbar>
      </AppBar>



      <Container maxWidth="xl" sx={{ mt: 3 }}>
        {/* CATEGORY VIEW */}
        {view === 'category' && (
          <Box sx={{ p: 2 }}>
            <Typography variant="h6">Services Section</Typography>

            <Box sx={{ display: 'flex', justifyContent: 'center', mt: 3 }}>
              <TextField
                placeholder="Enter new service..."
                variant="outlined"
                size="small"
                value={newService}
                onChange={(e) => setNewService(e.target.value)}
                sx={{
                  width: 400,
                  backgroundColor: 'white',
                  '& fieldset': {
                    borderTopRightRadius: 0,
                    borderBottomRightRadius: 0,
                    borderRight: 'none',
                  },
                }}
              />
              <Button
                variant="contained"
                color="primary"
                onClick={handleAddService}
                sx={{ borderTopLeftRadius: 0, borderBottomLeftRadius: 0 }}
              >
                <AddIcon />
              </Button>
            </Box>

            {/* Calendar Icon + Search (you can connect search later) */}
            <Box sx={{ mt: 3, display: 'flex', justifyContent: 'flex-end' }}>
              <Box display="flex" alignItems="center" gap={2}>
                <TextField variant="outlined" placeholder="Search..." size="small" sx={{ width: '170px' }} />
                <IconButton color="primary">
                  <CalendarTodayIcon />
                </IconButton>
              </Box>
            </Box>

            <TableContainer component={Paper} sx={{ mt: 3 }}>
              <Table>
                <TableHead>
                  <TableRow sx={{ backgroundColor: '#42a5f5' }}>
                    <TableCell align="center"><b>S.NO</b></TableCell>
                    <TableCell align="center"><b>Services</b></TableCell>
                    <TableCell align="center"><b>Actions</b></TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
  {rows.map((row, index) => (
    <TableRow
      key={row.id}
      sx={{ backgroundColor: index % 2 === 0 ? '#eeeeee' : 'transparent' }}
    >
      <TableCell align="center">{index + 1}</TableCell>

      <TableCell align="center">
        {editId === row.id ? (
          <TextField
            value={editServiceName}
            onChange={(e) => setEditServiceName(e.target.value)}
            size="small"
          />
        ) : (
          row.service_name
        )}
      </TableCell>

      <TableCell align="center">
        <Box display="flex" justifyContent="center" gap={1}>
          {editId === row.id ? (
            <>
              <Button
                variant="contained"
                color="success"
                size="small"
                onClick={() => handleUpdateService(row.id)}
              >
                Save
              </Button>
              <Button
                variant="outlined"
                color="secondary"
                size="small"
                onClick={() => {
                  setEditId(null);
                  setEditServiceName('');
                }}
              >
                Cancel
              </Button>
            </>
          ) : (
            <>
              <IconButton color="secondary" size="small" onClick={() => startEditing(row)}>
                <EditIcon />
              </IconButton>
              <IconButton color="error" size="small" onClick={() => handleDelete(row.id)}>
                <DeleteIcon />
              </IconButton>
            </>
          )}
        </Box>
      </TableCell>
    </TableRow>
  ))}
</TableBody>

              </Table>
            </TableContainer>
          </Box>
        )}


        {/* REGISTRATION FORM */}
        {view === 'registration' && (
          <Box sx={{ maxWidth: 700, mx: 'auto', mt: 2 }} component="form" onSubmit={handleSubmit}>
            <Paper sx={{ maxWidth: 700, p: 3, boxShadow: 3, height: 440, }}>
              <Box sx={{ backgroundColor: '#29b6f6', padding: 2, mb: 2 }}>
                <Typography variant='h5' sx={{ textAlign: 'center', color: '#7b1fa2' }}>
                  Reg Form
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', gap: 3 }}>
                <TextField fullWidth label="Full Name" margin="normal" />
                <TextField fullWidth label="Phone Number" margin="normal" type="number" />
              </Box>

              <Box sx={{ display: 'flex', gap: 3 }}>
                <TextField fullWidth label="Email" margin="normal" type="email" />
                <TextField fullWidth label="Address" margin="normal" />
              </Box>


              <Box sx={{ display: 'flex', gap: 3, mt: 2 }}>
                <FormControl fullWidth>
                  <InputLabel id="service-label">Service</InputLabel>
                  <Select labelId="service-label" defaultValue="">
                    <MenuItem value="haircut">Haircut</MenuItem>
                    <MenuItem value="facial">Facial</MenuItem>
                    <MenuItem value="makeup">Makeup</MenuItem>
                    <MenuItem value="face-makeup">Face Makeup</MenuItem>
                    <MenuItem value="skin">Skin</MenuItem>
                  </Select>
                </FormControl>

                <FormControl fullWidth>
                  <InputLabel id="location-label">Location</InputLabel>
                  <Select labelId="location-label" defaultValue="">
                    <MenuItem value="Sircilla">Sircilla</MenuItem>
                    <MenuItem value="Chandrampet">Chandrampet</MenuItem>
                    <MenuItem value="Mandepelly">Mandepelly</MenuItem>
                    <MenuItem value="Agraharam">Agraharam</MenuItem>
                    <MenuItem value="Ragudu">Ragudu</MenuItem>
                    <MenuItem value="ChinnaBonala">Chinna Bonala</MenuItem>
                  </Select>
                </FormControl>
              </Box>

              <Box sx={{ display: 'flex', gap: 3 }}>
                <TextField fullWidth type="date" margin="normal" />
                <TextField fullWidth label="Estimated Cost" type="number" margin="normal" />
              </Box>
              <Box sx={{ mt: 2, textAlign: 'center' }}>
                <Button type="submit" variant="contained" color="primary">
                  Submit Form
                </Button>
              </Box>
            </Paper>
          </Box>
        )}
      </Container>
    </>
  );
};

export default Beautycategory;
