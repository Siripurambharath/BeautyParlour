import React, { useState } from 'react';
import {
  Card, CardContent, Typography, Box, Grid, Button,
  TableBody, TableCell, TableContainer, Table, Paper, TableRow,
  AppBar, Toolbar, IconButton,
} from '@mui/material';

import { Link } from 'react-router-dom';
import ladylogo from "../Beautyfolder/images/lady logo.png";

const StudentDetails = () => {
  const [anchorEl, setAnchorEl] = useState(null);
   const [view, setView] = useState('category');  // Define the 'view' state here
  const open = Boolean(anchorEl);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleLogoClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  return (
    <Box>
      {/* Navbar */}
      <AppBar position="static" color="primary" sx={{ width: '100vw', left: 0 }}>
        <Toolbar sx={{ px: 2, display: 'flex', justifyContent: 'space-between' }}>
          {/* Left: Logo + Title */}
          <Box sx={{ display: 'flex', alignItems: 'center', flex: 1 }}>
            <IconButton edge="start" color="inherit" onClick={handleLogoClick} sx={{ mr: 1 }}>
              <img src={ladylogo} alt="Logo" style={{ height: 40, borderRadius: '50%' }} />
            </IconButton>
            <Typography variant="subtitle1" component="div" sx={{ fontSize: '1.1rem' }}>
              BeautyParlour
            </Typography>
          </Box>

          {/* Center: Category & Registration */}
   <Box sx={{ display: 'flex', justifyContent: 'space-between', flex: 1 }}>
            <Button color="inherit" sx={{ fontSize: '1.1rem' }} component={Link} to="/beautycategory">
              Category
            </Button>
            <Button color="inherit" sx={{ fontSize: '1.1rem' }} component={Link} to="/beautycategory">
              Registration
            </Button>
          </Box>

          {/* Right: Logout */}
          <Box sx={{ display: 'flex', justifyContent: 'flex-end', flex: 1 }}>
            <Button color="inherit" component={Link} to="/beautylogin" sx={{ fontSize: '1.1rem' }}>
              Logout
            </Button>
          </Box>
        </Toolbar>
      </AppBar>

      {/* Details Card */}
      <Card sx={{ maxWidth: 900, m: 2, p: 2, margin: 'auto',mt:3 }}>
        <CardContent sx={{ backgroundColor: '#a7ffeb', borderRadius: 2, p: 3 }}>
          <Typography variant="h4" sx={{ color: 'error.main', textAlign: 'center' }} gutterBottom>
            View Details
          </Typography>

          <Box sx={{ display: 'flex', justifyContent: 'center', mb: 2 }}>
            <img src={ladylogo} alt="logo" style={{ width: 200 }} />
          </Box>

          <TableContainer component={Paper} sx={{ mt: 3, width: 650, mx: 'auto', display: 'block' }}>
            <Table>
              <TableBody>
                <TableRow sx={{ backgroundColor: '#d9f9fd' }}>
                  <TableCell sx={{ pl: 5 }}><b>Name:</b></TableCell>
                  <TableCell>Anuskha</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell sx={{ pl: 5 }}><b>Service:</b></TableCell>
                  <TableCell>Facial</TableCell>
                </TableRow>
                <TableRow sx={{ backgroundColor: '#d9f9fd' }}>
                  <TableCell sx={{ pl: 5 }}><b>Phone Number:</b></TableCell>
                  <TableCell>6302403398</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell sx={{ pl: 5 }}><b>Email:</b></TableCell>
                  <TableCell>anuskha@gmail.com</TableCell>
                </TableRow>
                <TableRow sx={{ backgroundColor: '#d9f9fd' }}>
                  <TableCell sx={{ pl: 5 }}><b>Address:</b></TableCell>
                  <TableCell>123 Main Street</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell sx={{ pl: 5 }}><b>Location:</b></TableCell>
                  <TableCell>Indicators</TableCell>
                </TableRow>
                <TableRow sx={{ backgroundColor: '#d9f9fd' }}>
                  <TableCell sx={{ pl: 5 }}><b>Amount:</b></TableCell>
                  <TableCell>₹500</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell sx={{ pl: 5 }}><b>Date:</b></TableCell>
                  <TableCell>23-04-2025</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </TableContainer>
        </CardContent>

        <Grid item xs={12} sx={{ mt: 2, textAlign: 'center' }}>
          <Button
            variant="contained"
            component={Link}
            to="/beautytable"
            sx={{ backgroundColor: 'silver', color: 'black' }}
          >
            Back To List
          </Button>
        </Grid>
      </Card>
    </Box>
  );
};

export default StudentDetails;
